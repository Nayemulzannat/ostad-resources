<?php

// What is OOP? 
// Why OOP 
// Use Case 
// Terms Class,Object,Constructor,Inheritance, Abstraction, Final, Static, Access Modi, Namespace 

// 