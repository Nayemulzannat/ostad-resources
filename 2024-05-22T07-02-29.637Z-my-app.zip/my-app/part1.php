<?php

//Associative Array to JSON Object Encode

$person=["name"=>"OSTAD","age"=>34];

$JSON=json_encode($person);

echo $JSON;